from functions import move

import colorama                                                 
from colorama import *                                          
colorama.init()  

class Frame:
    def __init__(self):
        pass

    def printFrame(self, x, y, symbol1 = " ", symbol2=" ", defaultColor = Fore.WHITE, printColor = Fore.WHITE):
        print(defaultColor)
        move(y,x)

        print("╔───┐", sep="", end="")
        move(y+1,x)
        print("║" + printColor + symbol1.ljust(3) + defaultColor + "│", sep="", end="")
        move(y+2,x)
        print("║" + printColor + symbol2 + defaultColor + "  │", sep="", end="")
        move(y+3,x)
        print("╚═══╝", sep="", end="")
            
    def printUpperFrame(self, x, y, symbol1 = " ", symbol2=" ", defaultColor = Fore.WHITE, printColor = Fore.WHITE, showing = False):
        print(defaultColor)
        move(y,x)
        if showing:
            if symbol1 =="10":
                print("╔" + printColor + symbol1 + symbol2 + defaultColor + "┐", sep="", end="")
            else:
                print("╔─" + printColor + symbol1 + symbol2 + defaultColor + "┐", sep="", end="")
        else:
            print("╔───┐", sep="", end="")
