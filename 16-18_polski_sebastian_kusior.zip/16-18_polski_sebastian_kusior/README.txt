0. Rozpakuj projekt.
1. zaladuj biblioteki komendą

pip install -r .\requirements.txt
albo uruchom plik
'requirements.bat'

2. Otwórz plik solitaire.py
3. Sterowanie jest opisane w oknie gry. 
4. Powodzenia!