from Frame import Frame

import colorama                                                 
from colorama import *                                          
colorama.init()  
from config import cardsFigures
from config import cardsColors

class Card(Frame):
    def __init__(self, color = cardsColors[0], figure = cardsFigures[0], visible = False, toMove = False, placeholder = False):
        self.color = color
        self.figure = figure
        self.visible = visible
        self.toMove = toMove
        self.placeholder = placeholder

    def printCard(self, x ,y, onTop): #tu seba rob
        defaultColor = Fore.WHITE
        if self.toMove: defaultColor = Fore.YELLOW

        printColor = Fore.RED
        if self.color == cardsColors[2] or self.color == cardsColors[3]:
            printColor = Fore.LIGHTBLACK_EX
        
        if onTop:
            super().printFrame(x, y, self.figure, self.color, defaultColor, printColor)
        else:
            super().printUpperFrame(x,y, self.figure, self.color, defaultColor, printColor, self.visible)
