class Event():
    def __init__(self, fromSection, fromCollumn, toSection, toCollumn, amount):
        self.fromSection = fromSection
        self.fromCollumn = fromCollumn
        
        self.toSection = toSection
        self.toCollumn = toCollumn
        self.amount = amount