def move (y, x):
    print("\033[%d;%dH" % (y+1, x), end="")
