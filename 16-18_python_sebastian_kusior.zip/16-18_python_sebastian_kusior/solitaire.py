#   implementacja bilbiotek i modółów
import colorama                                                 #|kolorki
from colorama import *                                          #|
colorama.init()                                                 #|

import random                                                   # losowosc liczb
from pynput.keyboard import Key, Listener                       # wykrywanie klawiatury, poruszanie sie
import os


from config import *

from Frame import Frame
from Card import Card
from Event import Event

from functions import move

#   zmienne
score = 0
undoNumber = 3

menuX = 28
menuY = 3 + printOffsetY

onSection = 2
onCollumn = 0

selectedCollumn = -1
selectedSection = onSection

onMenu = True
onWin = False
toSwap = False

gameMode = 1 #1 - latwy, 3 - trudny
selectedCardsnumber = 0



stack = [] # karty do ciągnięcia
drawnStack = [] # karty pociągnięcia
tableCards = [] 
completedCards = []

shuffledCards = []
latestEvents = []

stackFrame = Frame()
drawnStackFrame = Frame()

#   funkcje wypisujące
def winMenu():
    global score
    scoreText = str(score).rjust(3) + " ruchów"

    print(Fore.WHITE)
    move(menuY,menuX);    print("┌────────────────────────┐")
    move(menuY+1,menuX);  print("│        Wygrałeś:       │")
    move(menuY+2,menuX);  print("│       W liczbie:       │")
    move(menuY+3,menuX);  print("│      " + scoreText + "        │", sep="")
    move(menuY+4,menuX);  print("│      Naciśnij 'r'      │")
    move(menuY+5,menuX);  print("│  aby zagrać ponownie   │")
    move(menuY+6,menuX);  print("└────────────────────────┘")

def menu():
    easy = "< Latwy >"
    hard = "< Trudny >"

    #latwy
    if gameMode == 1:
        easy = Fore.YELLOW + easy + Fore.WHITE
    #trudny
    else:
        hard = Fore.YELLOW + hard + Fore.WHITE
    
    print(Fore.WHITE)
    move(menuY,menuX);    print("┌────────────────────────┐")
    move(menuY+1,menuX);  print("│         Pasjans        │")
    move(menuY+2,menuX);  print("│      Wybierz tryb:     │")
    move(menuY+3,menuX);  print("│                        │")
    move(menuY+4,menuX);  print("│        "+easy+"       │")
    move(menuY+5,menuX);  print("│        "+hard+"      │")
    move(menuY+6,menuX);  print("└────────────────────────┘")

def drawTable():
    # Czyszczenie ekranu
    os.system('cls')
    printBorder()

    # Ustawienie domyślnego koloru
    print(Fore.WHITE, end="")


    # Wypisanie nagłówka
    move(0 + printOffsetY,printOffsetX)
    for collumn in range(collumns):
        print( " ─", collumn+1, "─ ", sep="", end="")

    # Wypisanie kolumn kart
    for collumn in range(0, collumns):
        for row in range(0, len(tableCards[collumn])):
            card = tableCards[collumn][row]
            if row == getLowestCardOnCollumn(collumn):
                card.printCard(collumn*5 + printOffsetX, row + printOffsetY+1, True)
            else:
                card.printCard(collumn*5 + printOffsetX, row + printOffsetY+1, False)

    # Wypisanie kart do dobierania

    move(0 + printOffsetY,5)
    print(Fore.WHITE + "W stosie: ", len(stack) , sep="", end="")
    move(1 + printOffsetY,5)
    print(Fore.WHITE + "Wynik: ", score , sep="", end="")

    stackFrame.printFrame(5,2+ printOffsetY, "?", " ")
    drawnStackFrame.printFrame(10,2+ printOffsetY)

    # Wypisanie dobranych kart
    for drawn in range(len(drawnStack)):
        if drawn == len(drawnStack) -1:
            drawnStack[drawn].printCard(10, 2 + drawn+ printOffsetY, True)
        else:
            drawnStack[drawn].printCard(10, 2 + drawn+ printOffsetY, False)

    # Wypisanie stosu ukompletowanego
    for cdCollumn in range(len(completedCards)):
        for card in range(len(completedCards[cdCollumn])):
            if completedCards[cdCollumn][card].placeholder and len(completedCards[cdCollumn]) == 1:
                color = completedCards[cdCollumn][card].color
                completedCards[cdCollumn][card].printFrame(collumns*5 + 23 + cdCollumn*5, 1 +card+ printOffsetY, color)
            else:
                if card == len(completedCards[cdCollumn]) -1:
                    completedCards[cdCollumn][card].printCard(collumns*5 + 23 + cdCollumn*5, 0 +card+ printOffsetY, True)
                else:
                    if not completedCards[cdCollumn][card].placeholder:
                        completedCards[cdCollumn][card].visible = True
                        completedCards[cdCollumn][card].printCard(collumns*5 + 23 + cdCollumn*5, 0 +card+ printOffsetY, False)

    # Wypisanie kursora
    match onSection:
        case 1:
            if onCollumn == 0:
                move(6+ printOffsetY, 5)
            else:
                upp = len(drawnStack)
                if len(drawnStack) == 0:
                    upp = 1
                move(5 + upp + printOffsetY, 10)
            
        case 2:
            move(getLowestCardOnCollumn(onCollumn) + 5 + printOffsetY, onCollumn * 5 + printOffsetX)
        case 3:
            move( 4 + len(completedCards[onCollumn]) + printOffsetY, collumns*5 + 23 + onCollumn*5)
    # Opcja flush jest konieczna zeby renderowalo sie wszystko na raz
    print( Fore.YELLOW + "╘═══╛", sep="", end="", flush=True) 


def printBorder():
    menuWidth = 79
    print(Fore.WHITE)
    move(0,1)
    print("┌" + "─"*menuWidth + "┐")
    for i in range(8):
        move(1+i,1)
        print("│" + " "*menuWidth + "│")
    
    file = open("instructions.txt", "r")
    j = 0
    for line in file:
        j+=1
        move(0+j, 5)
        print(line.strip())
    file.close()
    move(9,1)
    print("├" + "─"*menuWidth + "┤")

    for i in range(24):
        move(10+i,1)
        print("│" + " "*menuWidth + "│")
    move(34,1)
    print("└" + "─"*menuWidth + "┘")

# fukncje technieczne
def getLowestCardOnCollumn(collumn):
    return len(tableCards[collumn]) -1

def setupCards():
    global shuffledCards, score, stack, drawnStack, tableCards, completedCards, selectedCardsnumber, latestEvents, toSwap

    stack = []
    drawnStack = []

    tableCards = [] 
    completedCards = []
    selectedCardsnumber = 0
    score = 0
    shuffledCards = []
    latestEvents = []
    toSwap = False

    for figure in cardsFigures:
        for color in cardsColors:
            shuffledCards.append( Card(color, figure, False) )
    random.shuffle(shuffledCards)

    for color in cardsColors:
        completedCards.append( [Card(color, placeholder=True)] )

def setupTable():
    newTable = []
    for collumn in range(0, collumns):
        newTable.append([])
        for _collumn in range(0, collumn+1):
            newCard = shuffledCards.pop()
            newTable[collumn].append(newCard)

    return newTable

def setupStack():
    global stack
    for _ in range(len(shuffledCards)):
        stack.append(shuffledCards.pop())


def drawCard(number, place):
    if len(stack) < number:
        return

    for i in range(number):
        if(len(drawnStack) >= 3):
            for _ in range(number):
                stack.insert(0, drawnStack.pop(0))
        newCard = stack.pop()

        newCard.visible = True
        if place == -1:
            drawnStack.append(newCard)
        else:
            drawnStack.insert(place, newCard)

def on_press(key):
    global onWin, onSection, score, onCollumn, toSwap, selectedCollumn, selectedCardsnumber, selectedSection,gameMode, onMenu
    if not onMenu and not onWin:
    
        # Zdarzenie kliknięcia lewej strzałki
        if key == Key.left:
            match onSection:
                case 1:
                    if onCollumn == 1:
                        onCollumn-=1
                case 2:
                    if onCollumn == 0:
                        onSection = 1
                        onCollumn = 1
                    else:
                        onCollumn-=1
                case 3:
                    if onCollumn == 0:
                        onSection = 2
                        onCollumn = collumns-1
                    else:
                        onCollumn-=1

        # Zdarzenie kliknięcia prawej strzałki
        elif key == Key.right:
            match onSection:
                case 1:
                    if onCollumn == 1:
                        onSection = 2
                        onCollumn = 0
                    else:
                        onCollumn+=1
                case 2:
                    if onCollumn == collumns-1:
                        onSection = 3
                        onCollumn = 0
                    else:
                        onCollumn+=1
                case 3:
                    if onCollumn < len(completedCards)-1:
                        onCollumn+=1
        
        # Zdarzenie kliknięcia strzałki do góry
        elif key == Key.up:
            if toSwap and selectedCollumn == onCollumn and onSection == 2:
                if len(tableCards[selectedCollumn]) - selectedCardsnumber >0:
                    if tableCards[selectedCollumn][-selectedCardsnumber-1].visible:
                        tableCards[selectedCollumn][-selectedCardsnumber-1].toMove = True
                        selectedCardsnumber+=1

        
        # Zdarzenie kliknięcia strzałki do dołu
        elif key == Key.down:
            if toSwap and selectedCollumn == onCollumn and onSection == 2:
                if len(tableCards[selectedCollumn])>1:
                    tableCards[selectedCollumn][-selectedCardsnumber].toMove = False
                    selectedCardsnumber-=1
                if selectedCardsnumber == 0:
                    toSwap = False
        
        # Cofanie ruchu
        elif 'char' in dir(key) and key.char == "z":
            if len(latestEvents) > 0:
                event = latestEvents.pop()
                
                fromTable = []
                toTable = []
                if event.toSection == 2:
                    toTable = tableCards
                elif event.toSection == 3:
                    toTable = completedCards

                if event.fromSection == 1:

                    if event.fromCollumn == 0:
                        for _ in range(gameMode):
                            card = drawnStack.pop()
                            stack.append(card)
                        if event.amount == 3:
                            for _ in range( gameMode):
                                card = stack.pop(0)
                                drawnStack.insert(0, card)
                    else:
                        card = drawnStack.pop(0)
                        stack.insert(0, card)

                        returnCard =  toTable[event.toCollumn].pop()
                        drawnStack.append(returnCard)
                    score -=1
                    drawTable()
                    return
                elif event.fromSection == 2:
                    fromTable = tableCards
                elif event.fromSection == 3:
                    fromTable = completedCards

                if len(fromTable[event.fromCollumn]) > 0:
                    fromTable[event.fromCollumn][-1].visible = False

                flag = len(toTable[event.toCollumn]) - event.amount
                for i in range(event.amount):
                    returnCard =  toTable[event.toCollumn].pop(flag)
                    fromTable[event.fromCollumn].append(returnCard)
                score -= 1

        # Zdarzenie wybrou
        elif key == Key.enter:
            # Zmieniamy pozycję wybranej karty
            if toSwap:
                if onSection == 2 or onSection == 3:
                    changeLatestCard = False
                    canChange = False
                    if onCollumn == selectedCollumn and onSection == selectedSection:
                        if selectedSection == 1:
                            drawnStack[-1].toMove = False
                        elif selectedSection == 2:
                            for i in range(selectedCardsnumber):
                                tableCards[selectedCollumn][len(tableCards[selectedCollumn]) - i - 1].toMove = False
                        else:
                            completedCards[selectedCollumn][-1].toMove = False
                                
                        toSwap = False
                        selectedCardsnumber = 0
                        drawTable()
                        return
                    
                    if selectedSection == 1:
                        card = drawnStack[len(drawnStack)-1]
                    elif selectedSection == 2:
                        card = tableCards[selectedCollumn][-selectedCardsnumber]
                    else:
                        card = completedCards[selectedCollumn][-1]

                    if onSection == 2:
                        if len(tableCards[onCollumn]) != 0:
                            latestCard = tableCards[onCollumn][getLowestCardOnCollumn(onCollumn)]
                            changeLatestCard = True
                            if card.figure != cardsFigures[-1] and cardsFigures[ cardsFigures.index( latestCard.figure ) - 1] == card.figure:
                                if latestCard.color in [cardsColors[0], cardsColors[1]]:
                                    if card.color in [cardsColors[2], cardsColors[3]]:
                                        canChange = True
                                else:
                                    if card.color in [cardsColors[0], cardsColors[1]]:
                                        canChange = True
                        else:
                            if card.figure == "K":
                                canChange = True
                    else:
                        latestCard = completedCards[onCollumn][-1]
                        changeLatestCard = True
                        if latestCard.placeholder == True:
                            if card.figure == cardsFigures[0]:
                                if latestCard.color == card.color:
                                    canChange = True
                        else:
                            if latestCard.figure != cardsFigures[-1] and cardsFigures[ cardsFigures.index( latestCard.figure ) + 1] == card.figure:
                                if latestCard.color == card.color:
                                    canChange = True

                    if canChange:
                        if onSection == 2:
                            if changeLatestCard:  
                                latestCard.visible = True
                            if selectedSection == 1:
                                card = drawnStack.pop()
                                tableCards[onCollumn].append(card)
                                card.toMove = False

                                if gameMode == 3 or len(drawnStack) >= 2:
                                    drawCard(1, 0)

                            elif selectedSection == 2:
                                l = len(tableCards[selectedCollumn])-selectedCardsnumber
                                for i in range(selectedCardsnumber):
                                    card = tableCards[ selectedCollumn].pop(l)
                                    tableCards[onCollumn].append(card)
                                    card.toMove = False  
                            else:
                                card = completedCards[selectedCollumn].pop()
                                tableCards[onCollumn].append(card)
                                card.toMove = False
                                                        
                        else:
                            if selectedCardsnumber == 1 or selectedCollumn < 0:
                                if selectedCollumn >= 0:
                                    card = tableCards[ selectedCollumn].pop()
                                else:
                                    card = drawnStack.pop()
                                    if gameMode == 3  or len(drawnStack) >= 2:
                                        drawCard(1, 0)
                                completedCards[onCollumn].append(card)
                                card.toMove = False

                                sumLen = sum( len( completedCards[x]) for x in range(4))  
                                if sumLen == len(cardsColors) * (len(cardsFigures) + 1):
                                    onWin = True
                                    winMenu()
                                    return

                        if len(latestEvents) >= undoNumber:
                            latestEvents.remove(latestEvents[0])
                        latestEvents.append( Event(selectedSection, selectedCollumn, onSection, onCollumn, selectedCardsnumber) )
                        selectedCardsnumber = 0
                        toSwap = False
                        score += 1
                else:
                    if selectedSection == 1:
                        drawnStack[-1].toMove = False
                    elif selectedSection == 2:
                        tableCards[selectedCollumn][-1].toMove = False
                    else:
                        completedCards[selectedCollumn][-1].toMove = False
                    selectedCardsnumber = 0
                    toSwap = False

            # Wybieramy pierwszą kartę
            else:
                if onSection == 1:
                    # Ciągniemy karte
                    if onCollumn == 0:
                        
                        if len(latestEvents) >= undoNumber:
                            latestEvents.remove(latestEvents[0])
                        latestEvents.append( Event(1, 0, 1, 1, len(drawnStack)) )
                        drawCard(gameMode, -1)
                        score += 1
                    #Bierzemy z pociągnietego stosu
                    else:
                        if len(drawnStack) != 0:
                            selectedCollumn = -1
                            drawnStack[-1].toMove = True
                            toSwap = True
                elif onSection == 2:
                    # Gdy nie ma żadnej karty to nie ciągniemy
                    if len(tableCards[onCollumn]) == 0:
                        return
                    
                    selectedCardsnumber = 1
                    selectedCollumn = onCollumn
                    tableCards[onCollumn][-1].toMove = True
                    toSwap = True
                else:
                    if len(completedCards[onCollumn]) > 1:
                        selectedCardsnumber = 1
                        completedCards[onCollumn][-1].toMove = True
                        selectedCollumn = onCollumn
                        toSwap = True
                selectedSection = onSection
        drawTable()
    elif onWin:
        pass
    else:
        if key == Key.enter:
            onMenu = False
            game()
        elif key == Key.up and gameMode == 3:
            gameMode = 1
            menu()
        elif key == Key.down and gameMode == 1:
            gameMode = 3
            menu()

    if 'char' in dir(key) and key.char == "r":
        onMenu = True
        onWin = False
        menu()


def game():
    global tableCards
    setupCards()
    tableCards = setupTable()
    setupStack()
    drawTable()

#   punkt rozpoczęcia aplikacji
if __name__ == "__main__":
    os.system('cls')
    print(flush=True)
    printBorder()
    menu()
    with Listener(on_press = on_press) as listener:
        listener.join()


